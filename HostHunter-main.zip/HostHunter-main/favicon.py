"https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://techmedok.com&size=256"

      <link rel="stylesheet" href="https://fa6p.pages.dev/css/all.min.css">
